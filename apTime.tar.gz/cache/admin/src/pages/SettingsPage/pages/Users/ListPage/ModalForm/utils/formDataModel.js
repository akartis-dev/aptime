const formDataModel = {
  firstname: '',
  lastname: '',
  email: '',
  roles: [],
};

export default formDataModel;
