'use strict';

/**
 * data controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::data.data');
